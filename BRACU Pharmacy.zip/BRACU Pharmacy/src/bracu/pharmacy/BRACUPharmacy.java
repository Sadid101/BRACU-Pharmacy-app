/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bracu.pharmacy;

/**
 *
 * @author Sahanara Khatun
 */
public class BRACUPharmacy {
    
    public String name;
    public String company;
    public int amount;
    public String type;
    public int price;
    
    public BRACUPharmacy(String n, String c, int a, String t, int p){
        this.name=n;
        this.company=c;
        this.amount=a;
        this.type=t;
        this.price=p;
    }
    
    public String getName(){
        return name;
    }
    public String getComp(){
        return company;
    }
    public int getAmount(){
        return amount;
    }
    public String getType(){
        return type;
    }
    public int getPrice(){
        return price;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new MainMenu().setVisible(true);
        // TODO code application logic here
    }
    
}
